package map.example.projectdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ValueAnimator;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

public class TemperatureActivity extends AppCompatActivity {

    Button newsBtn, logBtn;
    Button news1Btn, news2Btn, news3Btn, news4Btn, news5Btn, news6Btn, news7Btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperature);

        newsBtn = findViewById(R.id.news_but);
        logBtn = findViewById(R.id.log_but);
        LinearLayout newsLayout = findViewById(R.id.news_layout);
        LinearLayout logLayout = findViewById(R.id.log_layout);

        news1Btn = findViewById(R.id.news_1);
        news2Btn = findViewById(R.id.news_2);
        news3Btn = findViewById(R.id.news_3);
        news4Btn = findViewById(R.id.news_4);
        news5Btn = findViewById(R.id.news_5);
        news6Btn = findViewById(R.id.news_6);
        news7Btn = findViewById(R.id.news_7);

        newsBtn.setOnClickListener(v -> {
            // Get the current height of logLayout
            int currentHeight = logLayout.getMeasuredHeight();

            // Create a ValueAnimator that animates from currentHeight to 0
            ValueAnimator animator_close = ValueAnimator.ofInt(currentHeight, 0);

            // Set the duration of the animation (in milliseconds)
            animator_close.setDuration(500); // for example, 500ms = 0.5s

            // Add an update listener to the animator
            animator_close.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator animation) {
                    // Get the animated value
                    int animatedValue = (int) animation.getAnimatedValue();

                    // Set the height of logLayout to the animated value
                    ViewGroup.LayoutParams params = logLayout.getLayoutParams();
                    params.height = animatedValue;
                    logLayout.setLayoutParams(params);
                }
            });

            // Start the animation
            animator_close.start();

            // Set the height of newsLayout to 0 initially
            ViewGroup.LayoutParams params = newsLayout.getLayoutParams();
            params.height = 0;
            newsLayout.setLayoutParams(params);
            newsLayout.requestLayout();
            newsLayout.measure(View.MeasureSpec.makeMeasureSpec(((View) newsLayout.getParent()).getWidth(), View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));

            // Get the height after layout
            int heightAfterLayout = newsLayout.getMeasuredHeight();

            // Create a ValueAnimator that animates from 0 to the new height
            ValueAnimator animator_open = ValueAnimator.ofInt(0, heightAfterLayout);

            // Set the duration of the animation (in milliseconds)
            animator_open.setDuration(500); // for example, 500ms = 0.5s

            // Add an update listener to the animator
            animator_open.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator animation) {
                    // Get the animated value
                    int animatedValue = (int) animation.getAnimatedValue();

                    // Set the height of newsLayout to the animated value
                    ViewGroup.LayoutParams params = newsLayout.getLayoutParams();
                    params.height = animatedValue;
                    newsLayout.setLayoutParams(params);
                }
            });

            // Start the animation
            animator_open.start();
        });
        logBtn.setOnClickListener(v -> {
            // Get the current height of newsLayout
            int currentHeight = newsLayout.getMeasuredHeight();

            // Create a ValueAnimator that animates from currentHeight to 0
            ValueAnimator animator_close = ValueAnimator.ofInt(currentHeight, 0);

            // Set the duration of the animation (in milliseconds)
            animator_close.setDuration(500); // for example, 500ms = 0.5s

            // Add an update listener to the animator
            animator_close.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator animation) {
                    // Get the animated value
                    int animatedValue = (int) animation.getAnimatedValue();

                    // Set the height of newsLayout to the animated value
                    ViewGroup.LayoutParams params = newsLayout.getLayoutParams();
                    params.height = animatedValue;
                    newsLayout.setLayoutParams(params);
                }
            });

            // Start the animation
            animator_close.start();

            // Set the height of logLayout to 0 initially
            ViewGroup.LayoutParams params = logLayout.getLayoutParams();
            params.height = 0;
            logLayout.setLayoutParams(params);
            logLayout.requestLayout();
            logLayout.measure(View.MeasureSpec.makeMeasureSpec(((View) logLayout.getParent()).getWidth(), View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));

            // Get the height after layout
            int heightAfterLayout = logLayout.getMeasuredHeight();

            // Create a ValueAnimator that animates from 0 to the new height
            ValueAnimator animator_open = ValueAnimator.ofInt(0, heightAfterLayout);

            // Set the duration of the animation (in milliseconds)
            animator_open.setDuration(500); // for example, 500ms = 0.5s

            // Add an update listener to the animator
            animator_open.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator animation) {
                    // Get the animated value
                    int animatedValue = (int) animation.getAnimatedValue();

                    // Set the height of logLayout to the animated value
                    ViewGroup.LayoutParams params = logLayout.getLayoutParams();
                    params.height = animatedValue;
                    logLayout.setLayoutParams(params);
                }
            });

            // Start the animation
            animator_open.start();
        });


        news1Btn.setOnClickListener(v -> {
            String videoLink = "https://www.uniindia.com/~/piracy-websites-pose-major-threat-to-indian-consumers-cyber-security-experts/Business%20Economy/news/3165736.html";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(videoLink));
            startActivity(intent);
        });
        news2Btn.setOnClickListener(v -> {
            String videoLink = "https://www.msn.com/en-in/news/other/piracy-sites-pose-bigger-threat-of-malware-infection-than-adult-sites-to-indian-consumers-isb-study/ar-BB1kaBiH";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(videoLink));
            startActivity(intent);
        });
        news3Btn.setOnClickListener(v -> {
            String videoLink = "https://www.business-standard.com/technology/tech-news/more-risk-of-malware-infection-while-accessing-pirated-websites-study-124032100096_1.html";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(videoLink));
            startActivity(intent);
        });
        news4Btn.setOnClickListener(v -> {
            String videoLink = "https://www.bbc.com/news/technology-27204123";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(videoLink));
            startActivity(intent);
        });
        news5Btn.setOnClickListener(v -> {
            String videoLink = "https://www.bbc.com/news/technology-38583357";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(videoLink));
            startActivity(intent);
        });
        news6Btn.setOnClickListener(v -> {
            String videoLink = "https://edition.cnn.com/2012/01/20/opinion/smith-sopa-support/index.html";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(videoLink));
            startActivity(intent);
        });
        news7Btn.setOnClickListener(v -> {
            String videoLink = "https://www.streamtvinsider.com/video/industry-voices-hawley-coronavirus-and-video-piracy-a-tale-two-movies";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(videoLink));
            startActivity(intent);
        });
    }
}
