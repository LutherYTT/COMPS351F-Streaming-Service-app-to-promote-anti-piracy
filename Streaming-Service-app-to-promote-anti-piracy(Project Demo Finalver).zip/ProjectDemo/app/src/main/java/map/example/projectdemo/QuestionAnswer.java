package map.example.projectdemo;

public class QuestionAnswer {

    public static String question[] ={
            "What is the primary purpose of anti-piracy measures?",
            "Which of the following actions is considered piracy?",
            "What is the potential consequence of engaging in piracy?",
            "Which statement best describes the concept of \"fair use\" in copyright law?",
            "How can consumers contribute to the fight against piracy?"

    };

    public static String choices[][] = {
            {"To promote the sharing of digital content","To protect intellectual property rights","To encourage unauthorized distribution","To limit access to digital media"},
            {"Sharing copyrighted music without permission","Buying a licensed copy of software","Creating a backup of your purchased movie","Using open-source software for commercial purposes"},
            {"Increased market competition","Improved access to content","Enhanced digital security","Legal penalties and fines"},
            {"Fair use allows unlimited sharing of copyrighted content","Fair use permits certain uses of copyrighted material without permission",
                    "Fair use requires payment of royalties for every use of copyrighted work",
                    "Fair use applies only to non-commercial purposes"},
            {"By reporting instances of piracy to relevant authorities","By actively promoting unauthorized sharing of content",
                    "By purchasing counterfeit goods","None of the above"}
    };

    public static String correctAnswers[] = {
            "To protect intellectual property rights",
            "Sharing copyrighted music without permission",
            "Legal penalties and fines",
            "Fair use permits certain uses of copyrighted material without permission",
            "By reporting instances of piracy to relevant authorities"
    };

}