package map.example.projectdemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

public class LocationActivity extends AppCompatActivity {
    ListView listView;
    ArrayAdapter<String> arrayAdapter;
    String[] codingList = {
            "freemoviesnow.xyz",
            "getallgamesforfree.com",
            "crackedsoftwaredownload.org",
            "streamlatestfilms.net",
            "piratedbookslibrary.cc",
            "fullseriesdownloadfree.tv",
            "watchanyshowanytime.biz",
            "freeblockbustermovies.co.uk",
            "unlimitedgamesandmovies.ru",
            "fastdownloadallcontent.com",
            "premiumcontentfreeaccess.info",
            "freehollywoodandbollywood.io",
            "allnewtvshowsfreedownload.org",
            "freemusicmp3sdownload.net",
            "leakalbumsandtracks.today",
            "directlinkfreemovies.com",
            "rapidsharemoviesandseries.cc",
            "torrentedpremiumapps.co",
            "getfreefilmswithoutpaying.com",
            "fullalbumzipdownloadfree.us"
    };


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);

        listView = findViewById(R.id.listView);
        arrayAdapter = new ArrayAdapter<String>(this,R.layout.list_customtext, codingList);
        listView.setAdapter(arrayAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){

        getMenuInflater().inflate(R.menu.actionbar_menu, menu);
        MenuItem menuItem = menu.findItem(R.id.search);
        SearchView searchView = (SearchView) menuItem.getActionView();
        searchView.setQueryHint("Search here");

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                arrayAdapter.getFilter().filter(newText);
                return false;
            }
        });


        return super.onCreateOptionsMenu(menu);
    }

}

