package map.example.projectdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class VideoActivity extends AppCompatActivity {

    TextView name7, content7;
    Button okBtn;
    EditText inputName, inputContent;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);

        okBtn = findViewById(R.id.ok_but);
        inputName = findViewById(R.id.input_name);
        inputContent = findViewById(R.id.input_content);
        name7 = findViewById(R.id.name7);
        content7 = findViewById(R.id.content7);

        okBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String textName = inputName.getText().toString();
                name7.setText(textName);
                name7.setTextSize(25);

                String textContent = inputContent.getText().toString();
                content7.setText(textContent);
                content7.setTextSize(25);
            }
        });

    }
}
